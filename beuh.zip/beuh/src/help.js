const help = (prefix) => {
	return `BOT G GUNA

*${prefix}owner*
*${prefix}info*
*${prefix}sticker*
*${prefix}tsticker*
*${prefix}nulis*
*${prefix}tts*
*${prefix}tiktok*
*${prefix}meme*
*${prefix}memeindo*
*${prefix}nsfwloli*
*${prefix}ocr*
*${prefix}loli*
*yt* [link]
*play* [judul lagu]
*${prefix}add* [62xxx]
*${prefix}kick* [tag]
*${prefix}setpp*
*${prefix}demote* [tag]
*${prefix}promote* [tag]
*${prefix}setpp*
*${prefix}group* [buka/tutup]
*${prefix}welcome* [1/0]
*${prefix}nsfw* [1/0]
*${prefix}simih* [1/0]
*${prefix}bc* 
*${prefix}leave*
*${prefix}clearall*
*${prefix}setprefix*
*${prefix}clone* [tag]
*${prefix}block*
*${prefix}unblock*
*${prefix}ytsearch*
*${prefix}listadmin*
*${prefix}blocklist*
*${prefix}simi*
*${prefix}wait*
*${prefix}fitnah*
*${prefix}tiktokstalk*
*${prefix}url2img*

SOUND:

 *salam*
 *tariksis*
 *baka*
 *desah*
 *goblok*
 *roti*
 *welot*
 *abangjago*`
}

exports.help = help

